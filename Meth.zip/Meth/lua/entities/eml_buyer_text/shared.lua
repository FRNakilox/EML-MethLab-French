ENT.Base = "base_gmodentity";
ENT.Type = "anim";

ENT.PrintName		= "Au toxicomane";
ENT.Category 		= "EML";

ENT.Contact    		= "";
ENT.Purpose 		= "";
ENT.Instructions 	= "" ;

ENT.Spawnable			= false;
ENT.AdminSpawnable		= false;
