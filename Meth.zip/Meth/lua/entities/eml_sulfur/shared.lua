ENT.Base = "base_gmodentity";
ENT.Type = "anim";

ENT.PrintName		= "Soufre";
ENT.Category 		= "EML";

ENT.Contact    		= "";
ENT.Purpose 		= "";
ENT.Instructions 	= "" ;

ENT.Spawnable			= true;
ENT.AdminSpawnable		= true;
